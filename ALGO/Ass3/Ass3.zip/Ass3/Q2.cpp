#include <iostream>
#include <fstream>
#include <string>

using namespace std;

bool matchFirstPattern(const string& str) {
    int state = 0;

    for (char ch : str) {
        switch (state) {
        case 0: if (ch == 'b') state = 1; break;
        case 1: if (ch == 'a') state = 2; break;
        case 2: if (ch == 'a' || ch == 'b' || ch == 'c') state = 3; else return false; break;
        case 3:
            if (ch == 'd') state = 4;
            else if (ch != 'a' && ch != 'b' && ch != 'c') return false;
            break;
        case 4: if (ch == 'b') return true; else return false;
        }
    }
    return false;
}

bool matchSecondPattern(const string& str) {
    int state = 0;

    for (char ch : str) {
        switch (state) {
        case 0: if (ch == 'b') state = 1; break;
        case 1: if (ch == 'a') state = 2; break;
        case 2: if (ch == 'a' || ch == 'b' || ch != 'c') state = 3; else return false; break;
        case 3:
            if (ch == 'd') state = 4;
            else if (ch != 'a' && ch != 'b' && ch != 'c') return false;
            break;
        case 4:
            if (ch == 'b') state = 5;
            else if (ch != 'd' && ch != 'a') return false;
            break;
        case 5:
            if (ch == 'd' || ch == 'a') state = 6;
            else return false;
            break;
        case 6:
            if (ch == 'b') state = 7;
            else if (ch != 'd' && ch != 'a') return false;
            break;
        case 7: if (ch == 'c') return true; else return false;
        }
    }
    return false;
}

int main() {
    ifstream file("Problem2.txt");
    if (!file) {
        cerr << "File could not be opened" << endl;
        return 1;
    }

    string line, pattern, str;
    int expectedOutput;

    while (getline(file, line)) {
        // Check if the line is a pattern
        if (line.find('+') != string::npos || line.find('(') != string::npos) {
            pattern = line;
            continue;
        }

        // Read the test string and expected output
        str = line;
        if (!(file >> expectedOutput)) break;
        file.ignore(); // To ignore the newline after the integer

        bool result;
        if (pattern == "ba(a|b|c)+db") {
            result = matchFirstPattern(str);
        }
        else if (pattern == "ba(a|b|c)+db+(d|a)+bc") {
            result = matchSecondPattern(str);
        }
        else {
            cerr << "Unknown pattern: " << pattern << endl;
            continue;
        }

        cout << "String: " << str << " - Pattern Match: " << result;
        cout << " - Expected: " << expectedOutput << (result == expectedOutput ? " (Pass)" : " (Fail)") << endl;
    }

    file.close();
    return 0;
}
