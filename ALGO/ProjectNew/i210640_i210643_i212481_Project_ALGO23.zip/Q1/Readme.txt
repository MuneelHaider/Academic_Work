1)	The first Line contains the n(sq cm) value

2)	Second onwards line contain (multiple of five, multiple of five) dimensions that make up
	a multiple of 100 followed by the price associated with the dimension in curly brackets '{}'.

3)	Make sure to check the multiple of 100 that the dimensions are making instead of assuming
	100,200,300 in order.

4)	The multiples of 100 will not be fixed, (ex. test case 2 going till 600 sq cm)

5) 	Have a generic file reading function as you will be provided with different test cases
	(following the same pattern) in your demo.

6)	The answers of the test case are given in the question pdf.

7)	Your final output should have the maximized profit and the path(dimensions) used to maximize the profit.
