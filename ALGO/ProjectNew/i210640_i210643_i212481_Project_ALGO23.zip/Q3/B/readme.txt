1. First line has the number of vertices 
2. Then there are all the connection
3. Then there is an expected output 
4. And the resulting cycle (if any)