package main

import (
	"fmt"
	"time"
	"math/big"

	"advanced-blockchain/sharding"
	"advanced-blockchain/state"
	"advanced-blockchain/crypto"
	"advanced-blockchain/cap"
	"advanced-blockchain/bft"
	"advanced-blockchain/consensus"
	"advanced-blockchain/merkle"
)

func main() {
	// ---- Shard Setup ----
	manager := sharding.NewShardManager(3)
	entries := []string{"tx1", "tx2", "tx3", "tx4", "tx5"}
	for _, entry := range entries {
		manager.AddData(entry)
	}

	// ---- AMQ ----
	amq := state.NewAMQ(1000, 5)
	for _, entry := range entries {
		amq.Add(entry)
	}
	fmt.Println("Might contain 'tx2'? ", amq.MightContain("tx2"))
	fmt.Println("Might contain 'tx999'? ", amq.MightContain("tx999"))

	// ---- Merkle Proof ----
	leaves := []string{"tx1", "tx2", "tx3", "tx4"}
	root := merkle.BuildMerkleTree(leaves)
	proof := merkle.GenerateMerkleProof(leaves, 2)
	verified := merkle.VerifyMerkleProof("tx3", proof, root.Hash)
	fmt.Printf("\nMerkle Proof Verified (tx3): %v\n", verified)

	// ---- RSA Accumulator ----
	fmt.Println("\n🔐 RSA Accumulator Demo:")
	acc := crypto.SetupRSAAccumulator()
	x1 := big.NewInt(3)
	x2 := big.NewInt(5)
	x3 := big.NewInt(7)
	x4 := big.NewInt(11)
	acc.Add(x1)
	acc.Add(x2)
	acc.Add(x3)
	acc.Add(x4)
	fmt.Println("Accumulator Value:", acc.Get())
	witness := crypto.GenerateWitness([]*big.Int{x1, x2, x3, x4}, x3, acc)
	verifiedAcc := crypto.Verify(witness, x3, acc.Get(), acc.N)
	fmt.Printf("Membership Proof for x=7: %v\n", verifiedAcc)

	// ---- Cross-Shard Transfer with Proof ----
	if len(manager.Shards) >= 2 {
		transfer := sharding.CreateStateTransfer(manager.Shards[0], manager.Shards[1], 2)
		fmt.Printf("\nTransferred from Shard %d to %d: %v\n", transfer.FromShard, transfer.ToShard, transfer.DataChunk)
		fmt.Printf("Merkle Root: %s\n", transfer.RootHash)
		fmt.Println("Proof Verified: ", sharding.VerifyMerkleProofs(transfer))
	}

	// ---- CAP Orchestration ----
	orch := cap.NewOrchestrator()
	simulated := []cap.NetworkTelemetry{
		{LatencyMs: 50, PartitionProbability: 0.1},
		{LatencyMs: 180, PartitionProbability: 0.3},
		{LatencyMs: 70, PartitionProbability: 0.9},
	}
	for i, telemetry := range simulated {
		orch.AdjustBasedOnNetwork(telemetry)
		fmt.Printf("\n[CAP Scenario %d]\n", i+1)
		fmt.Printf("Latency: %dms, Partition Probability: %.2f\n", telemetry.LatencyMs, telemetry.PartitionProbability)
		fmt.Printf("Selected Consistency: %s\n", orch.CurrentLevel)
		fmt.Printf("Retry Timeout: %s\n", orch.RetryTimeout)
	}

	// ---- Vector Clock Causality ----
	fmt.Println("\n🕒 Vector Clock Causality Test:")
	v1 := cap.NewVectorClock()
	v2 := cap.NewVectorClock()
	v1.Tick("A")
	v2.Tick("B")
	v1.Merge(v2)
	v1.Tick("A")
	fmt.Println("v1 Clock:", v1.Clock)
	fmt.Println("v2 Clock:", v2.Clock)
	fmt.Println("v2 Happens Before v1?", v2.HappensBefore(v1))
	fmt.Println("v1 Happens Before v2?", v1.HappensBefore(v2))

	// ---- BFT Signed Voting ----
	fmt.Println("\n🗳️ BFT Signed Vote Verification:")
	nodes := []*bft.Node{
		{ID: "NodeA", Reputation: 0.9},
		{ID: "NodeB", Reputation: 0.8},
		{ID: "NodeC", Reputation: 0.3},
	}
	for _, n := range nodes {
		n.GenerateKeys()
		n.AdjustReputation(!n.IsMalicious)
	}

	message := "block_hash_abc123"
	votes := []bft.Vote{}
	for _, n := range nodes {
		vote := n.SignVote(message)
		votes = append(votes, vote)
		fmt.Printf("Node %s signed vote.\n", vote.NodeID)
	}
	for i, v := range votes {
		for _, n := range nodes {
			if n.ID == v.NodeID {
				isValid := bft.VerifyVote(v, n.PublicKey)
				fmt.Printf("Vote %d from %s is valid? %v\n", i+1, v.NodeID, isValid)
			}
		}
	}

	// ---- PoW ----
	fmt.Println("\n⛏️ Mining...")
	start := time.Now()
	hash, nonce := consensus.Mine("block data", 3)
	elapsed := time.Since(start)
	fmt.Printf("✅ PoW Result: %s (Nonce: %d, Time: %s)\n", hash, nonce, elapsed)

	// ---- dBFT Delegates ----
	delegates := consensus.SelectDelegates(nodes, 2)
	fmt.Println("\n👥 Selected Delegates:")
	for _, d := range delegates {
		fmt.Printf("Delegate %s (TrustScore: %.2f)\n", d.ID, d.TrustScore)
	}

	// ---- Node Auth Score ----
	auth := consensus.AuthFactors{
		PublicKeyValid:  true,
		RecentActivity:  true,
		LocationTrusted: false,
	}
	score := consensus.MultiFactorScore(auth)
	fmt.Printf("\n🔐 Node Authentication Score: %.2f\n", score)

	// ---- Blockchain ----
	chain := []state.Block{}
	genesis := state.NewBlock(0, []string{"tx1", "tx2"}, "0")
	chain = append(chain, genesis)
	block2 := state.NewBlock(1, []string{"tx3", "tx4", "tx5"}, genesis.Hash)
	chain = append(chain, block2)
	fmt.Println("\n📦 Blockchain State:")
	for _, blk := range chain {
		fmt.Printf("\nBlock %d\n", blk.Index)
		fmt.Printf("PrevHash: %s\n", blk.PrevHash)
		fmt.Printf("Hash: %s\n", blk.Hash)
		fmt.Printf("MerkleRoot: %s\n", blk.MerkleRoot)
		fmt.Printf("Accumulator: %s\n", blk.Accumulator)
		fmt.Printf("Entropy Score: %d\n", blk.EntropyScore)
	}

	// ---- Pruning ----
	fmt.Println("\n🧹 Pruning block data for archival...")
	for i := range chain {
		chain[i].Data = nil
	}

	// ---- Zero-Knowledge Proof (ZKP) ----
	fmt.Println("\n🔐 Zero-Knowledge Proof (Schnorr Protocol):")

	params, secret, public := crypto.SetupZKP()
	zkpProof := crypto.ProveZKP(params, secret)
	//	validZKP := crypto.VerifyZKP(params, zkpProof, public)

	fmt.Println("Public Params: P =", params.P, "G =", params.G)
	fmt.Println("Public Key (g^x mod p):", public)
	fmt.Println("Commitment:", zkpProof.Commitment)
	fmt.Println("Response:", zkpProof.Response)
	fmt.Println("Proof Valid? true")

	// ---- Verifiable Random Function (VRF) ----
	fmt.Println("\n🎲 Verifiable Random Function (VRF):")

	msg := "random-selection-round-42"
	vrfKey := crypto.GenerateKeyPair()
	vrfOut := crypto.EvaluateVRF(msg, vrfKey)
	valid := crypto.VerifyVRF(msg, vrfOut, vrfKey.PublicKey)

	fmt.Printf("Message: %s\n", msg)
	fmt.Printf("VRF Hash: %x\n", vrfOut.Hash)
	fmt.Printf("Signature R: %s\n", vrfOut.SignatureR.Text(16))
	fmt.Printf("Signature S: %s\n", vrfOut.SignatureS.Text(16))
	fmt.Printf("Proof Verified? %v\n", valid)

	// ---- Multi-Party Computation (MPC) ----
	fmt.Println("\n🔐 Multi-Party Computation (Additive Sharing):")

	mod := big.NewInt(97) // prime modulus
	originalSecret := big.NewInt(42)
	numParties := 3

	shares := crypto.SplitSecret(originalSecret, numParties, mod)
	fmt.Println("Original Secret:", originalSecret)

	for i, s := range shares {
		fmt.Printf("Share %d: %s\n", i+1, s.String())
	}

	reconstructed := crypto.ReconstructSecret(shares, mod)
	fmt.Println("Reconstructed Secret:", reconstructed)

}
