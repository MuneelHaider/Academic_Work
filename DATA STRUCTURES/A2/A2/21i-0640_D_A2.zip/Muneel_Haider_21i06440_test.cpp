#include "pch.h"
#include "Muneel_Haider_21i06440_Q1.h"
#include "Muneel_Haider_21i06440_Q2.h"
#include "Muneel_Haider_21i06440_Q3.h"
#include "Muneel_Haider_21i06440_Q4.h"

// Muneel_Haider_21i0640

void TOPMenuTest() {

	system("CLS");
	system("color 3");

	cout << "******************************************" << endl;
	cout << "*					 *" << endl;
	cout << "*	Muneel Haider 21i-0640		 *" << endl;
	cout << "*	Assignment 3 Data Structures	 *" << endl;
	cout << "*					 *" << endl;
	cout << "******************************************" << endl;

	cout << endl << endl << endl << endl << endl;
}

int main()
{

	TOPMenuTest();

	 mainOfQuestion1();

	cin.ignore();
	
	 mainOfQuestion2();

	cin.ignore();

	 mainOfQuestion3();

	cin.ignore();

	 mainOfQuestion4();

}