#include <opencv2/core.hpp>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/highgui.hpp>
#include "Part_1.h"
#include "Part_2.h"
#include "Part_3.h"
#include "Classes.h"
#include <iostream>
#include <fstream>
using namespace cv;
using namespace std;

/*      Muneel Haider       
        21i-0640        
        Assignment 4    */    

int main() {

    system("Color 3");

    cout << endl << "Muneel Haider";
    cout << endl << "21i-0640";
    cout << endl << "Assignment 4" << endl << endl << endl;

    mainOfP1();

    return 0;
}