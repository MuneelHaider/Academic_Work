﻿namespace DBProject
{
    partial class AddAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddAdmin));
            usernametxt = new TextBox();
            passwordtxt = new TextBox();
            emailtxt = new TextBox();
            fullnametxt = new TextBox();
            addresstxt = new TextBox();
            cnictxt = new TextBox();
            dobtxt = new TextBox();
            gendertxt = new TextBox();
            contacttxt = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            signupadminbutton = new Button();
            pictureBox1 = new PictureBox();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button3 = new Button();
            button1 = new Button();
            panel2 = new Panel();
            label12 = new Label();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // usernametxt
            // 
            usernametxt.Location = new Point(493, 233);
            usernametxt.Name = "usernametxt";
            usernametxt.Size = new Size(125, 27);
            usernametxt.TabIndex = 0;
            // 
            // passwordtxt
            // 
            passwordtxt.Location = new Point(493, 403);
            passwordtxt.Name = "passwordtxt";
            passwordtxt.Size = new Size(125, 27);
            passwordtxt.TabIndex = 1;
            // 
            // emailtxt
            // 
            emailtxt.Location = new Point(494, 296);
            emailtxt.Name = "emailtxt";
            emailtxt.Size = new Size(125, 27);
            emailtxt.TabIndex = 2;
            // 
            // fullnametxt
            // 
            fullnametxt.Location = new Point(494, 351);
            fullnametxt.Name = "fullnametxt";
            fullnametxt.Size = new Size(125, 27);
            fullnametxt.TabIndex = 4;
            // 
            // addresstxt
            // 
            addresstxt.Location = new Point(493, 460);
            addresstxt.Name = "addresstxt";
            addresstxt.Size = new Size(125, 27);
            addresstxt.TabIndex = 5;
            // 
            // cnictxt
            // 
            cnictxt.Location = new Point(926, 239);
            cnictxt.Name = "cnictxt";
            cnictxt.Size = new Size(125, 27);
            cnictxt.TabIndex = 6;
            // 
            // dobtxt
            // 
            dobtxt.Location = new Point(926, 289);
            dobtxt.Name = "dobtxt";
            dobtxt.Size = new Size(125, 27);
            dobtxt.TabIndex = 7;
            // 
            // gendertxt
            // 
            gendertxt.Location = new Point(926, 344);
            gendertxt.Name = "gendertxt";
            gendertxt.Size = new Size(125, 27);
            gendertxt.TabIndex = 8;
            // 
            // contacttxt
            // 
            contacttxt.Location = new Point(926, 396);
            contacttxt.Name = "contacttxt";
            contacttxt.Size = new Size(125, 27);
            contacttxt.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(343, 233);
            label1.Name = "label1";
            label1.Size = new Size(122, 31);
            label1.TabIndex = 10;
            label1.Text = "Username:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(350, 403);
            label2.Name = "label2";
            label2.Size = new Size(115, 31);
            label2.TabIndex = 11;
            label2.Text = "Password:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(390, 289);
            label3.Name = "label3";
            label3.Size = new Size(75, 31);
            label3.TabIndex = 12;
            label3.Text = "Email:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(343, 346);
            label4.Name = "label4";
            label4.Size = new Size(122, 31);
            label4.TabIndex = 13;
            label4.Text = "Full Name:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(363, 456);
            label5.Name = "label5";
            label5.Size = new Size(102, 31);
            label5.TabIndex = 14;
            label5.Text = "Address:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(791, 235);
            label6.Name = "label6";
            label6.Size = new Size(70, 31);
            label6.TabIndex = 15;
            label6.Text = "CNIC:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(801, 286);
            label7.Name = "label7";
            label7.Size = new Size(60, 31);
            label7.TabIndex = 16;
            label7.Text = "DOB";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(1062, 288);
            label8.Name = "label8";
            label8.Size = new Size(144, 28);
            label8.TabIndex = 17;
            label8.Text = "Ex. 2002-07-25";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(777, 340);
            label9.Name = "label9";
            label9.Size = new Size(94, 31);
            label9.TabIndex = 18;
            label9.Text = "Gender:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.White;
            label10.Location = new Point(1104, 346);
            label10.Name = "label10";
            label10.Size = new Size(69, 28);
            label10.TabIndex = 19;
            label10.Text = "M or F";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = Color.White;
            label11.Location = new Point(773, 392);
            label11.Name = "label11";
            label11.Size = new Size(98, 31);
            label11.TabIndex = 20;
            label11.Text = "Contact:";
            // 
            // signupadminbutton
            // 
            signupadminbutton.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            signupadminbutton.Location = new Point(685, 600);
            signupadminbutton.Name = "signupadminbutton";
            signupadminbutton.Size = new Size(136, 46);
            signupadminbutton.TabIndex = 21;
            signupadminbutton.Text = "SIGNUP";
            signupadminbutton.UseVisualStyleBackColor = true;
            signupadminbutton.Click += signupadminbutton_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.Location = new Point(886, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(114, 122);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(64, 64, 64);
            button7.Cursor = Cursors.Hand;
            button7.Image = (Image)resources.GetObject("button7.Image");
            button7.Location = new Point(0, 511);
            button7.Name = "button7";
            button7.Size = new Size(250, 135);
            button7.TabIndex = 5;
            button7.Text = "View Courses";
            button7.TextImageRelation = TextImageRelation.ImageAboveText;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(64, 64, 64);
            button6.Cursor = Cursors.Hand;
            button6.Image = (Image)resources.GetObject("button6.Image");
            button6.Location = new Point(0, 385);
            button6.Name = "button6";
            button6.Size = new Size(250, 135);
            button6.TabIndex = 4;
            button6.Text = "View Faculty";
            button6.TextImageRelation = TextImageRelation.ImageAboveText;
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(64, 64, 64);
            button5.Cursor = Cursors.Hand;
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.Location = new Point(0, 258);
            button5.Name = "button5";
            button5.Size = new Size(250, 135);
            button5.TabIndex = 3;
            button5.Text = "View Admins";
            button5.TextImageRelation = TextImageRelation.ImageAboveText;
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(64, 64, 64);
            button3.Cursor = Cursors.Hand;
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.Location = new Point(0, 125);
            button3.Name = "button3";
            button3.Size = new Size(250, 135);
            button3.TabIndex = 1;
            button3.Text = "Add New Admin";
            button3.TextImageRelation = TextImageRelation.ImageAboveText;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(64, 64, 64);
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.Location = new Point(37, 26);
            button1.Name = "button1";
            button1.Size = new Size(61, 29);
            button1.TabIndex = 0;
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(64, 64, 64);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(pictureBox1);
            panel2.Dock = DockStyle.Top;
            panel2.ForeColor = SystemColors.ActiveCaptionText;
            panel2.Location = new Point(250, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1000, 125);
            panel2.TabIndex = 24;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(289, 50);
            label12.Name = "label12";
            label12.Size = new Size(316, 54);
            label12.TabIndex = 1;
            label12.Text = "Add New Admin";
            label12.TextAlign = ContentAlignment.TopCenter;
            label12.Click += label12_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(64, 64, 64);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Left;
            panel1.ForeColor = SystemColors.ControlText;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 804);
            panel1.TabIndex = 23;
            // 
            // AddAdmin
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1250, 804);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(signupadminbutton);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(contacttxt);
            Controls.Add(gendertxt);
            Controls.Add(dobtxt);
            Controls.Add(cnictxt);
            Controls.Add(addresstxt);
            Controls.Add(fullnametxt);
            Controls.Add(emailtxt);
            Controls.Add(passwordtxt);
            Controls.Add(usernametxt);
            Name = "AddAdmin";
            Text = "AddAdmin";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox usernametxt;
        private TextBox passwordtxt;
        private TextBox emailtxt;
        private TextBox fullnametxt;
        private TextBox addresstxt;
        private TextBox cnictxt;
        private TextBox dobtxt;
        private TextBox gendertxt;
        private TextBox contacttxt;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Button signupadminbutton;
        private PictureBox pictureBox1;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button3;
        private Button button1;
        private Panel panel2;
        private Label label12;
        private Panel panel1;
    }
}