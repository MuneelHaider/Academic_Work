﻿namespace DBProject
{
    partial class facultySignup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(facultySignup));
            label1 = new Label();
            label2 = new Label();
            label4 = new Label();
            label3 = new Label();
            usernametext = new TextBox();
            passtext = new TextBox();
            emailtext = new TextBox();
            fullnametext = new TextBox();
            signupfaculty = new Button();
            addresstxt = new TextBox();
            cnictxt = new TextBox();
            dobtxt = new TextBox();
            gendertxt = new TextBox();
            contacttxt = new TextBox();
            departmenttxt = new TextBox();
            officetxt = new TextBox();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            label12 = new Label();
            label13 = new Label();
            pictureBox1 = new PictureBox();
            button7 = new Button();
            button3 = new Button();
            button6 = new Button();
            button4 = new Button();
            button5 = new Button();
            label14 = new Label();
            panel2 = new Panel();
            panel1 = new Panel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.Transparent;
            label1.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label1.ForeColor = Color.White;
            label1.Location = new Point(373, 193);
            label1.Name = "label1";
            label1.Size = new Size(126, 32);
            label1.TabIndex = 0;
            label1.Text = "Username:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Transparent;
            label2.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label2.ForeColor = Color.White;
            label2.Location = new Point(791, 191);
            label2.Name = "label2";
            label2.Size = new Size(116, 32);
            label2.TabIndex = 1;
            label2.Text = "Password:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.Transparent;
            label4.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label4.ForeColor = Color.White;
            label4.Location = new Point(423, 252);
            label4.Name = "label4";
            label4.Size = new Size(76, 32);
            label4.TabIndex = 3;
            label4.Text = "Email:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.Transparent;
            label3.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(760, 357);
            label3.Name = "label3";
            label3.Size = new Size(147, 32);
            label3.TabIndex = 4;
            label3.Text = "Department:";
            // 
            // usernametext
            // 
            usernametext.Location = new Point(505, 196);
            usernametext.Name = "usernametext";
            usernametext.Size = new Size(164, 27);
            usernametext.TabIndex = 5;
            usernametext.TextChanged += textBox1_TextChanged;
            // 
            // passtext
            // 
            passtext.Location = new Point(913, 196);
            passtext.Name = "passtext";
            passtext.Size = new Size(193, 27);
            passtext.TabIndex = 6;
            // 
            // emailtext
            // 
            emailtext.Location = new Point(507, 252);
            emailtext.Name = "emailtext";
            emailtext.Size = new Size(164, 27);
            emailtext.TabIndex = 7;
            // 
            // fullnametext
            // 
            fullnametext.Location = new Point(913, 250);
            fullnametext.Name = "fullnametext";
            fullnametext.Size = new Size(193, 27);
            fullnametext.TabIndex = 8;
            // 
            // signupfaculty
            // 
            signupfaculty.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            signupfaculty.Location = new Point(713, 539);
            signupfaculty.Name = "signupfaculty";
            signupfaculty.Size = new Size(140, 53);
            signupfaculty.TabIndex = 9;
            signupfaculty.Text = "SIGNUP";
            signupfaculty.UseVisualStyleBackColor = true;
            signupfaculty.Click += signupfaculty_Click;
            // 
            // addresstxt
            // 
            addresstxt.Location = new Point(507, 309);
            addresstxt.Name = "addresstxt";
            addresstxt.Size = new Size(164, 27);
            addresstxt.TabIndex = 11;
            // 
            // cnictxt
            // 
            cnictxt.Location = new Point(913, 307);
            cnictxt.Name = "cnictxt";
            cnictxt.Size = new Size(193, 27);
            cnictxt.TabIndex = 12;
            // 
            // dobtxt
            // 
            dobtxt.Location = new Point(505, 472);
            dobtxt.Name = "dobtxt";
            dobtxt.Size = new Size(166, 27);
            dobtxt.TabIndex = 13;
            // 
            // gendertxt
            // 
            gendertxt.Location = new Point(913, 420);
            gendertxt.Name = "gendertxt";
            gendertxt.Size = new Size(193, 27);
            gendertxt.TabIndex = 14;
            // 
            // contacttxt
            // 
            contacttxt.Location = new Point(507, 363);
            contacttxt.Name = "contacttxt";
            contacttxt.Size = new Size(164, 27);
            contacttxt.TabIndex = 15;
            // 
            // departmenttxt
            // 
            departmenttxt.Location = new Point(913, 362);
            departmenttxt.Name = "departmenttxt";
            departmenttxt.Size = new Size(193, 27);
            departmenttxt.TabIndex = 16;
            // 
            // officetxt
            // 
            officetxt.Location = new Point(507, 419);
            officetxt.Name = "officetxt";
            officetxt.Size = new Size(162, 27);
            officetxt.TabIndex = 17;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = Color.Transparent;
            label5.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = Color.White;
            label5.Location = new Point(790, 250);
            label5.Name = "label5";
            label5.Size = new Size(117, 32);
            label5.TabIndex = 18;
            label5.Text = "Fullname:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = Color.Transparent;
            label6.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = Color.White;
            label6.Location = new Point(396, 303);
            label6.Name = "label6";
            label6.Size = new Size(103, 32);
            label6.TabIndex = 19;
            label6.Text = "Address:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = Color.White;
            label7.Location = new Point(834, 302);
            label7.Name = "label7";
            label7.Size = new Size(73, 32);
            label7.TabIndex = 20;
            label7.Text = "CNIC:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.BackColor = Color.Transparent;
            label8.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label8.ForeColor = Color.White;
            label8.Location = new Point(431, 467);
            label8.Name = "label8";
            label8.Size = new Size(68, 32);
            label8.TabIndex = 21;
            label8.Text = "DOB:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = Color.White;
            label9.Location = new Point(810, 413);
            label9.Name = "label9";
            label9.Size = new Size(97, 32);
            label9.TabIndex = 22;
            label9.Text = "Gender:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.BackColor = Color.Transparent;
            label10.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label10.ForeColor = Color.White;
            label10.Location = new Point(398, 358);
            label10.Name = "label10";
            label10.Size = new Size(101, 32);
            label10.TabIndex = 23;
            label10.Text = "Contact:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.BackColor = Color.Transparent;
            label11.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = Color.White;
            label11.Location = new Point(416, 414);
            label11.Name = "label11";
            label11.Size = new Size(83, 32);
            label11.TabIndex = 24;
            label11.Text = "Office:";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.BackColor = Color.Transparent;
            label12.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = Color.White;
            label12.Location = new Point(680, 467);
            label12.Name = "label12";
            label12.Size = new Size(173, 32);
            label12.TabIndex = 25;
            label12.Text = "Ex. 2002-07-25";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.BackColor = Color.Transparent;
            label13.Font = new Font("Segoe UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = Color.White;
            label13.Location = new Point(1112, 420);
            label13.Name = "label13";
            label13.Size = new Size(84, 32);
            label13.TabIndex = 26;
            label13.Text = "M or F";
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.BackgroundImage = (Image)resources.GetObject("pictureBox1.BackgroundImage");
            pictureBox1.Location = new Point(886, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(114, 122);
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(64, 64, 64);
            button7.Cursor = Cursors.Hand;
            button7.Image = (Image)resources.GetObject("button7.Image");
            button7.Location = new Point(0, 508);
            button7.Name = "button7";
            button7.Size = new Size(250, 135);
            button7.TabIndex = 19;
            button7.Text = "View Courses";
            button7.TextImageRelation = TextImageRelation.ImageAboveText;
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(64, 64, 64);
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.Location = new Point(12, 12);
            button3.Name = "button3";
            button3.Size = new Size(62, 29);
            button3.TabIndex = 7;
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(64, 64, 64);
            button6.Cursor = Cursors.Hand;
            button6.Image = (Image)resources.GetObject("button6.Image");
            button6.Location = new Point(0, 382);
            button6.Name = "button6";
            button6.Size = new Size(250, 135);
            button6.TabIndex = 18;
            button6.Text = "View Faculty";
            button6.TextImageRelation = TextImageRelation.ImageAboveText;
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(64, 64, 64);
            button4.Cursor = Cursors.Hand;
            button4.Image = (Image)resources.GetObject("button4.Image");
            button4.Location = new Point(0, 122);
            button4.Name = "button4";
            button4.Size = new Size(250, 135);
            button4.TabIndex = 16;
            button4.Text = "Add New Admin";
            button4.TextImageRelation = TextImageRelation.ImageAboveText;
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(64, 64, 64);
            button5.Cursor = Cursors.Hand;
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.Location = new Point(0, 255);
            button5.Name = "button5";
            button5.Size = new Size(250, 135);
            button5.TabIndex = 17;
            button5.Text = "View Admins";
            button5.TextImageRelation = TextImageRelation.ImageAboveText;
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 24F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(273, 41);
            label14.Name = "label14";
            label14.Size = new Size(412, 54);
            label14.TabIndex = 8;
            label14.Text = "Update Admin Details";
            // 
            // panel2
            // 
            panel2.BackColor = Color.FromArgb(64, 64, 64);
            panel2.Controls.Add(label14);
            panel2.Controls.Add(pictureBox1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(250, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(1000, 125);
            panel2.TabIndex = 28;
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(64, 64, 64);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button5);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 804);
            panel1.TabIndex = 27;
            // 
            // facultySignup
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1250, 804);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label13);
            Controls.Add(label12);
            Controls.Add(label11);
            Controls.Add(label10);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(officetxt);
            Controls.Add(departmenttxt);
            Controls.Add(contacttxt);
            Controls.Add(gendertxt);
            Controls.Add(dobtxt);
            Controls.Add(cnictxt);
            Controls.Add(addresstxt);
            Controls.Add(signupfaculty);
            Controls.Add(fullnametext);
            Controls.Add(emailtext);
            Controls.Add(passtext);
            Controls.Add(usernametext);
            Controls.Add(label3);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "facultySignup";
            Text = "facultySignup";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label4;
        private Label label3;
        private TextBox usernametext;
        private TextBox passtext;
        private TextBox emailtext;
        private TextBox fullnametext;
        private Button signupfaculty;
        private TextBox addresstxt;
        private TextBox cnictxt;
        private TextBox dobtxt;
        private TextBox gendertxt;
        private TextBox contacttxt;
        private TextBox departmenttxt;
        private TextBox officetxt;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label label12;
        private Label label13;
        private PictureBox pictureBox1;
        private Button button7;
        private Button button3;
        private Button button6;
        private Button button4;
        private Button button5;
        private Label label14;
        private Panel panel2;
        private Panel panel1;
    }
}