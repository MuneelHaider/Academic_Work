#pragma once
#include<string>
#include<iostream>
using namespace std;

/*		Muneel Haider		*
*		21i-0640			*
*		LAB 05				*/

int LCM(int a, int b, int c) {

	if (b == 0) {

		return a;
    }

	return LCM(b, a % b, 1);
}

int LCM(int num1, int num2) {

	return (num1 / LCM(num1, num2, 1) * num2);
}

int Power(int a,int b) {

	if (b != 0) {

		return (a * Power(a, b - 1));
	}
	else {

		return 1;
	}
}

int* sequence(int num,int* result,int size, int counter) {

	if (*result % 2 == 0) {

		*(result + 1)  = *result / 2;
	}

	else if (*result == 1) {

		return result;
	}

	else if(*result % 2 != 0) {

		*(result + 1) = (*result * 3) + 1;
	}

	sequence(num, ++result, size, 1);
}

int* sequence(int num, int* result, int size) {

	*result = num;

	sequence(num, result, size, 1);

	return result;
}