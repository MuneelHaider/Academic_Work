#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include "Payment.h"
using namespace std;

class Cart {

protected:

	int total_items;
	int bill;
	string* itemsNames = new string[total_items];

public:

	Cart(){
	
		total_items = 0;
		bill = 0;
	}

	void add_item(string s) {

		itemsNames[total_items] = s;
		total_items++;

		cout << endl << "Item has been added to cart successfully." << endl;
	}

	void remove_items(string s) {

		string temp;

		for (int i = 0; i < total_items; i++) {

			if (itemsNames[i] == s) {

				for (int j = i; j < total_items; j++) {

					temp = itemsNames[j + 1];
					itemsNames[j + 1] = itemsNames[j];
					itemsNames[j] = temp;
				}

				cout << endl << "Item removed succesfully." << endl;

				total_items--;
				break;
			}
		}
	}
};

class Feedback {

protected:

	string feedback;

public:

	Feedback() {

		feedback = "";
	}

	string setFeedback() {

		string temp;

		getline(cin, temp);

		feedback = temp;

		cout << endl << "Your feedback has been saved succesfully." << endl << endl;

		return feedback;
	}

	void getFeedback() {

		cout << "Feedback:" << endl;
		cout << feedback << endl;
	}
};