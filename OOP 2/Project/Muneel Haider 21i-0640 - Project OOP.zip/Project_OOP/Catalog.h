#pragma once
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

class Catalog {

protected:

	int camount;
	char** catalog_items = new char*[camount];
	int* prices = new int [camount];

public:

	Catalog() {

		camount = 0;
		ifstream Reader;
		Reader.open("CatalogItems.txt", ios::in);
		string temp = "1";

		while (!Reader.eof()) {

			getline(Reader, temp);
			camount++;
		}

		Reader.close();

		catalog_items = new char* [camount];
		for (int i = 0; i < camount; i++) {

			catalog_items[i] = new char[20];
		}

		ReadCatalogFromFiles();
	}

	int getCAmount() {

		return camount;
	}

	void ReadCatalogFromFiles() {

		ifstream Reader;

		Reader.open("CatalogItems.txt", ios::in);
		string temp;
		int counter = 0;
		char* lmao = new char[20];

		catalog_items = new char* [camount];
		for (int i = 0; i < camount; i++) {
		
			catalog_items[i] = new char[20];
		}

		for (int i = 0; i < camount; i++) {

			getline(Reader, temp);
			
			for (int j = 0; j < temp.length(); j++) {

				lmao[j] = temp[j];
				lmao[j + 1] = '\0';
			}

			for (int j = 0; j < temp.length(); j++) {

				catalog_items[i][j] = lmao[j];
				catalog_items[i][j + 1] = '\0';
			}
		}

		Reader.close();

		Reader.open("CatalogPrices.txt", ios::in);

		// For prices
		for (int i = 0; i < camount; i++) {

			Reader >> prices[i];
		}

		Reader.close();
	}

	bool searchCatalog(string s) {

		for (int i = 0; i < camount; i++) {

			if (s == catalog_items[i]) {

				return true;
			}
		}

		return false;
	}

	int getPrice(string s) {

		for (int i = 0; i < camount; i++) {

			if (s == catalog_items[i]) {

				return prices[i];
			}
		}
	}

	void add_product(string s, int p) {

		ofstream Writer;
		Writer.open("CatalogItems.txt", ios::app);
		Writer << endl << s;	
		Writer.close();

		Writer.open("CatalogPrices.txt", ios::app);
		Writer << endl << p;
		camount++;
		Writer.close();

		ReadCatalogFromFiles();

		cout << endl << "Product has been added succesfully." << endl << endl;
	}

	void remove_product(string s, int p) {

		char* temp = new char[20];
		int lmao;

		for (int i = 0; i < camount; i++) {

			if (catalog_items[i] == s) {
				if (prices[i] == p) {

					for (int j = i; j < camount; j++) {

						temp = catalog_items[i + 1];
						catalog_items[i + 1] = catalog_items[i];
						catalog_items[i] = temp;

						lmao = prices[i + 1];
						prices[i + 1] = prices[i];
						prices[i] = lmao;
					}

					camount--;
					break;
				}
			}
		}

		writeToFile();

		cout << endl << endl << "Product has been removed succesfully." << endl << endl;
	}

	void writeToFile() {

		ofstream Writer;
		Writer.open("CatalogItems.txt", ios::trunc);

		Writer << catalog_items[0];

		for (int i = 1; i < camount; i++) {

			Writer << endl << catalog_items[i];
		}
	
		Writer.close();
	}

	void seeCatalog() {

		cout << "CATALOG ITEMS" << endl << endl << endl;
		cout << "\tItems\t\tPrices:" << endl << endl;

		for (int i = 0; i < camount; i++) {

			cout << i << ".\t" << catalog_items[i] << "\t\t" << prices[i] << endl;
		}
	}
};