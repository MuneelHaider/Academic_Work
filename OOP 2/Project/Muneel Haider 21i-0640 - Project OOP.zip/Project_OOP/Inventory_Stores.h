#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include "Catalog.h"
#include "User.h"
#include "User2.h"
using namespace std;

class Inventory {

protected:

	int amount;
	char** name_of_items = new char * [amount];
	Catalog* catalog;

public:

	Inventory(Catalog obj) : catalog(&obj) {

		amount = 0;
		ifstream Reader;
		Reader.open("InventoryItems.txt", ios::in);
		string temp;

		while (!Reader.eof()) {

			getline(Reader, temp);
			amount++;
		}

		name_of_items = new char* [amount];
		for (int i = 0; i < amount; i++) {

			name_of_items[i] = new char[20];
		}

		Reader.close();

		ReadInventoryFromFiles();
	}

	void ReadInventoryFromFiles() {

		ifstream Reader;

		Reader.open("InventoryItems.txt", ios::in);
		string temp;
		char* lol = new char[20];

		name_of_items = new char* [amount];
		for (int i = 0; i < amount; i++) {

			name_of_items[i] = new char[20];
		}

		for (int i = 0; i < amount; i++) {

			getline(Reader, temp);
			
			for (int j = 0; j < temp.length(); j++) {
			
				lol[j] = temp[j];
				lol[j + 1] = '\0';
			}

			for (int j = 0; j < temp.length(); j++) {

				name_of_items[i][j] =lol[j];
				name_of_items[i][j + 1] = '\0';
			}
		}

		Reader.close();
	}

	void add_product(string s) {

		if (catalog->searchCatalog(s)) {
			ofstream Writer;
			Writer.open("InventoryItems.txt", ios::app);
			Writer << endl << s;
			amount++;
			Writer.close();

			ReadInventoryFromFiles();

			cout << endl << "Product has been added succesfully in Inventory." << endl << endl;
		}
	}

	void remove_product(string s) {

		char* temp = new char[20];

		for (int i = 0; i < amount; i++) {
			
			if (name_of_items[i] == s) {

				for (int j = i; j < amount - 1; j++) {

					temp = name_of_items[j];
					name_of_items[j] = name_of_items[j + 1];
					name_of_items[j + 1] = temp;
				}

				cout << endl << endl << "Product has been removed." << endl << endl;

				amount--;
				break;
			}
		}

		removefromFile();
	}

	void removefromFile() {

		ofstream Writer;
		Writer.open("InventoryItems.txt", ios::trunc);

		Writer << name_of_items[0];

		for (int i = 1; i < amount; i++) {

			Writer << endl << name_of_items[i];
		}

		Writer.close();
	}

	void view_inventory() {

		cout << endl << endl << "Following is the inventory of the store." << endl << endl;

		for (int i = 0; i < amount; i++) {

			cout << i << ".\t" << name_of_items[i] << endl;
		}
	}

	int getInventoryAmount() {

		return amount;
	}

	bool search_inventory(string s) {

		for (int i = 0; i < amount; i++) {

			if (name_of_items[i] == s) {

				return true;
			}
		}

		return false;
	}

};


class Stores {

protected:

	Inventory inventor;
	string location;
	Catalog* catalog;

public:

	Stores(string l, Catalog obj) : catalog(&obj), inventor(obj) {

		location = l;
	}

	void addProduct(string t) {

		inventor.add_product(t);
	}

	void removeProduct(string s) {

		inventor.remove_product(s);
	}

	int getInventAmountStore() {

		return inventor.getInventoryAmount();
	}

	bool searchInventoryStore(string t) {

		return inventor.search_inventory(t);
	}

	string getLocal() {

		return location;
	}

	void viewInventoryStore() {

		inventor.view_inventory();
	}
};