#pragma once
#include <iostream>
using namespace std;

class Payment {

protected:

	string location;
	bool delivery_is_local;
	string account_number;

public:

	Payment() {}
	Payment(string l, bool d, string an) {

		location = l;
		delivery_is_local = d;
		account_number = an;
	}

	string getLocation() {

		return location;
	}
	void setLocation(string l) {

		location = l;
	}

	bool getDeliveryLocal() {

		return delivery_is_local;
	}
	void setDeliveryLocal(bool f) {

		delivery_is_local = f;
	}

	string getAccountNumber() {

		return account_number;
	}
	void setAccountNumber(string a) {

		account_number = a;
	}

	void TransactionOptions(int b) {

		cout << endl << endl << "Your total bill is:\t\t" << b << endl << endl << endl;
		int option;
		int total = b;

		cout << "Please choose one of the following options: " << endl << endl;
		cout << "\t1.\tJazzCash." << endl;
		cout << "\t2.\tCredit / Debit Card." << endl;
		cout << "\t3.\tCash and Delivery." << endl;
		cout << "\t4.\tEasyPaisa." << endl;
		cout << "\tInput:\t";

		cin >> option;
		cout << endl << endl;
		
		if (option == 1) {

			getDetails1();
		}
		else if (option == 2) {

			getDetails();
		}
		else if (option == 3) {

			getDetails2();
		}
		else if (option == 4) {

			getDetails3();
		}
		else {

			cout << "Wrong option. Please try again." << endl << endl;
			TransactionOptions(b);
		}

		total += 50;
		cout << endl << "An extra 50 rupees has been charged for your delivery fees." << endl << endl;
		cout << "TOTAL CHARGES: " << total << endl << endl;
	}

	void getDetails() {

		char temp[100];

		cout << "Please enter your credit / debit card number without spaces:\t";
		cin >> temp;

		cout << endl << "Enter your CVC:\t";
		cin >> temp;

		cout << endl << "Enter your expiry date:\t";
		cin >> temp;

		cout << endl << endl << "Please wait till we confirm your details." << endl;

		Cash_recieved();
	}

	void getDetails3() {

		char temp[100];

		cout << "Enter phone number:\t";
		cin >> temp;

		cout << endl << endl << "Please wait till we confirm your details." << endl;

		Cash_recieved();
	}

	void getDetails2() {

		char temp[100];

		cout << "Enter address:\t";
		cin >> temp;

		cout << endl << endl << "Please wait till we confirm your details." << endl;

		Cash_recieved();
	}

	void getDetails1() {

		char temp[100];

		cout << "Enter Phone Number:\t";
		cin >> temp;

		cout << endl << endl << "Please wait till we confirm your details." << endl;

		Cash_recieved();
	}

	void Delivered() {

		cout << "Congratulations! Your product has been delivered!" << endl;
	}

	void Cash_recieved() {

		cout << "Your order has been confirmed. You will recieve a notification on your device soon." << endl;

		Delivered();
	}
};

class CreditCard : public Payment {

protected:

	bool transaction_status;

public:

	CreditCard() {}
	CreditCard(string l, bool d, string an) {

		location = l;
		delivery_is_local = d;
		account_number = an;
		transaction_status = false;
	}

	void getDetails() {

		string temp;

		cout << "Please enter your credit / debit card number:\t";
		cin >> temp;

		cout << endl << "Enter your CVC:\t";
		cin >> temp;

		cout << endl << "Enter your expiry date:\t";
		cin >> temp;

		cout << endl << endl << "Please wait till we confirm your details." << endl;

		Cash_recieved();
	}

	void Delivered() {

		cout << "Congratulations! Your product has been delivered!" << endl;
	}

	void Cash_recieved() {

		cout << "Your order has been confirmed. You will recieve a notification on your device soon." << endl;

		Delivered();
	}
};

class JazzCash : public Payment {

protected:

	bool transaction_status;

public:

	JazzCash() {}
	JazzCash(string l, bool d, string an) {

		location = l;
		delivery_is_local = d;
		account_number = an;
		transaction_status = false;
	}

	void getDetails() {

		string temp;

		cout << "Enter Phone Number:\t";
		cin >> temp;

		cout << endl << endl << "Please wait till we confirm your details." << endl;

		Cash_recieved();
	}

	void Delivered() {

		cout << "Congratulations! Your product has been delivered!" << endl;
	}

	void Cash_recieved() {

		cout << "Your order has been confirmed. You will recieve a notification on your device soon." << endl;

		Delivered();
	}
};

class CashAndDelivery : public Payment {

protected:

	bool transaction_status;

public:

	CashAndDelivery() {}
	CashAndDelivery(string l, bool d, string an) {

		location = l;
		delivery_is_local = d;
		account_number = an;
		transaction_status = false;
	}

	void getDetails() {

		string temp;

		cout << "Enter address:\t";
		cin >> temp;

		cout << endl << endl << "Please wait till we confirm your details." << endl;

		Cash_recieved();
	}

	void Delivered() {

		cout << "Congratulations! Your product has been delivered!" << endl;
	}

	void Cash_recieved() {

		cout << "Your order has been confirmed. You will recieve a notification on your device soon." << endl;

		Delivered();
	}
};

class EasyPaisa : public Payment {

protected:

	bool transaction_status;

public:

	EasyPaisa() {}
	EasyPaisa(string l, bool d, string an) {

		location = l;
		delivery_is_local = d;
		account_number = an;
		transaction_status = false;
	}

	void getDetails() {

		string temp;

		cout << "Enter phone number:\t";
		cin >> temp;

		cout << endl << endl << "Please wait till we confirm your details." << endl;

		Cash_recieved();
	}

	void Delivered() {

		cout << "Congratulations! Your product has been delivered!" << endl;
	}

	void Cash_recieved() {

		cout << "Your order has been confirmed. You will recieve a notification on your device soon." << endl;

		Delivered();
	}
};