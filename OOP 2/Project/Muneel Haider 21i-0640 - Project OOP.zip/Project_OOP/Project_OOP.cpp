#include <iostream>
#include <fstream>
#include <string>
#include "Catalog.h"
#include "Inventory_Stores.h"
using namespace std;

int main() {

	cout << "Hello my nigga, back to the lobby." << endl;

	Catalog C;
	
	C.seeCatalog();
	C.add_product("SUHAYB", 10);
	C.seeCatalog();
	C.remove_product("SUHAYB", 10);
	C.seeCatalog();

	Inventory In(C);
	In.view_inventory();
	In.add_product("Eggs");
	In.view_inventory();
	In.remove_product("Eggs");
	In.view_inventory();
	
	Payment P;
	P.TransactionOptions(100);

	return 0;
}