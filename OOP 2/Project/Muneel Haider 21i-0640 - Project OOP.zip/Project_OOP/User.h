#pragma once
#include <iostream>
#include <fstream>
#include "Cart_Feedback.h"
#include "Catalog.h"
#include "Payment.h"
#include "Inventory_Stores.h"
using namespace std;


class User {

protected:

	string name;
	int ID;
	string password;
	string typeOfPerson;
	bool logIn;

public:

	User() {}
	User(string n, int i, string p, string type) {

		name = n;
		ID = i;
		password = p;
		typeOfPerson = type;
		logIn = false;
	}

	string getName() {

		return name;
	}
	void setName(string n) {

		name = n;
	}

	int getID() {

		return ID;
	}
	void setID(int i) {

		ID = i;
	}

	string getPassword() {

		return password;
	}
	void setPassword(string p) {

		password = p;
	}

	string getType() {

		return typeOfPerson;
	}
	void setType(string t) {

		typeOfPerson = t;
	}

	bool getLogiOrNot() {

		return logIn;
	}
	void setLogInOrNot(bool i) {

		logIn = i;
	}
};

class Admin : public User {

protected:

	//	catalog Catalog;
	//	franchises Stores;
	int number_of_customers;
	int number_of_managers;
	//	Customer_SignUp customer;
	//	Manager_SignUp manager;

public:

	Admin() {}
	/*	Admin(string n, int i, string p, catalog c, Stores s, Customer_SignUp cus, Manager_SignUp man) {


		}*/

	void display_A() {

		cout << "Name:		" << name << endl;
		cout << "ID:		" << ID << endl;
		cout << "Password:	" << password << endl;
		cout << "Type:		" << typeOfPerson << endl;
	}

	int getCustomersAmount() {

		return number_of_customers;
	}
	void setCustomersAmount(int s) {

		number_of_customers = s;
	}

	int getManagersAmount() {

		return number_of_managers;
	}
	void setManagersAmount(int i) {

		number_of_managers = i;
	}

	Admin operator=(Admin& obj) {

		name = obj.name;
		ID = obj.ID;
		password = obj.password;
		typeOfPerson = obj.typeOfPerson;
		logIn = obj.logIn;

		return *this;
	}
};