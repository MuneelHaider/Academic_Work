#pragma once
#include <iostream>
#include "User.h"
#include "Inventory_Stores.h"
#include "Catalog.h"
#include "Payment.h"
using namespace std;



class Customer : public User {

protected:

	Cart cart;
	Feedback feedback;
	Payment checkout;
//	Catalog* catalog;
	Inventory* inventor;
	string local;
	int bill;

public:

	Customer() {}
	Customer(string n, int i, string pass, string type, bool log, string loc, Catalog obj, Inventory obj2) : catalog(&obj), inventor(&obj2) {

		name = n;
		password = pass;
		ID = i;
		typeOfPerson = type;
		logIn = log;
		local = loc;
		bill = 0;

	}
};
	/*
	void DisplayMenu_C() {

		int lmao;
		int lol;
		int sus;
		string item;
		bool flag = false;

		cout << endl << "Welcome " << name << "!" << endl;
		cout << "What would you like to do?" << endl << endl;
		cout << "1. View Catalog and Shop." << endl;
		cout << "2. Give Feedback." << endl;
		cout << "3. Check-Out and Pay." << endl;

		cin >> lmao;

		//		View Catalog and Buy
		if (lmao == 1) {

			catalog->seeCatalog();

			cout << "Would you like to proceed to shopping? If yes please press 1. Else press 0." << endl;
			cin >> lol;

			if (lol == 0) {

				DisplayMenu_C();
			}
			else if (lol == 1) {

				do {

					catalog->seeCatalog();

					cout << endl << endl << "Please choose which products you want to add in your cart." << endl;
					cin >> item;

					for (int i = 0; i < inventory->getInventoryAmount(); i++) {

						if (inventory->search_inventory(item)) {

							cout << endl << "The product is now included in your cart." << endl;
							cart.add_item(item);
							inventory->remove_product(item);
							bill += catalog->getPrice(item);
						}
					}

					cout << endl << "Would you like to checkout, for browse for more?" << endl << endl;
					cout << "1.\tBrowse for more." << endl;
					cout << "2.\tProceed to CheckOut." << endl;
					cin >> sus;

					if (sus == 2) {

						flag = true;
					}

				} while (flag == false);

				checkout.TransactionOptions(bill);
			}
		}
		else if (lmao == 2) {

			feedback.setFeedback();

			cout << endl << endl << "Please enter 1 to return to main page" << endl;
			cin >> lol;

			DisplayMenu_C();
		}
		else if (lmao == 3) {

			checkout.TransactionOptions(bill);
		}
	}
};

class Manager : public User {

protected:

	string branch;
	Catalog* cataloging;
	Stores* store;

public:

	Manager() {}
	Manager(Catalog obj, Stores obj2) : cataloging(&obj), store(&obj2) {

		branch = obj2.getLocal();
	}

	void DisplayMenu_M() {

		int option;
		int o1;
		string temp;

		cout << endl << endl << "Welcome " << name << "!" << endl;
		cout << "You have succesfully logged in. Your branch location is: " << branch;
		cout << endl << endl << "What would you want to proceed with?" << endl << endl;

		cout << "1.\tEdit products in Inventory." << endl;
		cout << "2.\tSearch for an item in Inventory." << endl;
		cout << "3.\tView available products in Inventory." << endl << endl;
		cout << "4.\tExit." << endl;
		cout << "Input: ";
		cin >> option;

		if (option == 1) {

			if (branch == store->getLocal()) {

				cout << endl << endl << endl;
				cout << "Please choose further options." << endl << endl;
				cout << "1. Add Product in Inventory." << endl;
				cout << "2. Remove Product from Inventory." << endl;
				cout << "3. Go back." << endl << endl;
				cout << "Input: ";
				cin >> o1;

				if (o1 == 1) {

					cout << endl << endl;
					cout << "Which product do you want to add in the Inventory?" << endl;
					cin >> temp;

					for (int i = 0; i < cataloging->getCAmount(); i++) {

						if (cataloging->searchCatalog(temp)) {

							store->addProduct(temp);
							DisplayMenu_M();
						}
					}
				}
				else if (o1 == 2) {

					cout << endl << endl;
					cout << "Which product do you want to remove from the Inventory?" << endl;
					cin >> temp;

					if (store->searchInventoryStore(temp)) {

						store->removeProduct(temp);
						DisplayMenu_M();
					}
				}
				else {

					cout << endl << endl << "Incorrect option." << endl;
					DisplayMenu_M();
				}
			}
			else {

				cout << endl << "You are not allowed to access this area." << endl << endl;
				DisplayMenu_M();
			}
		}
		else if (option == 2) {

			cout << endl << endl << "Which item are you searching for?" << endl;
			cout << "Input:\t";
			cin >> temp;

			if (store->searchInventoryStore(temp)) {

				cout << "Name:\t\tPrice:" << endl;
				cout << temp << "\t\t" << cataloging->getPrice(temp) << endl << endl;

				cout << "Press 1 to go back to main menu." << endl;
				cin >> o1;
				DisplayMenu_M();
			}
		}
		else if (option == 3) {

			store->viewInventoryStore();

			cout << "Press 1 to go back to main menu." << endl;
			cin >> o1;
			DisplayMenu_M();
		}
		else {

			// Add Login Page
		}
	}

};

*/