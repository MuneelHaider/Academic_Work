#!/bin/bash

# Muneel Haider
# 21i-0640

echo "Parameter 1: $1"
echo "Parameter 2: $2"
echo "Parameter 3: $3"

echo

echo "All environment variables:"
env