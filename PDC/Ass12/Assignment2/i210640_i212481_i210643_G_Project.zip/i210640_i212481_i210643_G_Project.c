#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <mpi.h>
#include <omp.h>

/*
    Muneel Haider       i210640
    Muhammad Abdullah   i210643
    Abdullah Zahoor     i212481

    PDC Project
*/

typedef struct {

    int node;
    int cost;
} Queue;

void findKShortest(int edges[][3], int n, int m, int k, int rank, int size) {
    
    int sizePerProcess = m / size;
    int start = rank * sizePerProcess;
    int end = (rank == size - 1) ? m : (start + sizePerProcess);

    Queue** q = (Queue**)malloc((n + 1) * sizeof(Queue*));
    for (int i = 0; i <= n; ++i) {

        q[i] = NULL;
    }

    int* qSize = (int*)calloc(n + 1, sizeof(int));

    if (rank == 0) {

        for (int i = 0; i < m; ++i) {
        
            int lol = edges[i][0];
            Queue* newQueue = (Queue*)realloc(q[lol], (qSize[lol] + 1) * sizeof(Queue));

            q[lol] = newQueue;
            q[lol][qSize[lol]].node = edges[i][1];
            q[lol][qSize[lol]].cost = edges[i][2];
            qSize[lol]++;
        }

        int** arrayDistance = (int**)malloc((n + 1) * sizeof(int*));

        for (int i = 0; i <= n; ++i) {
        
            arrayDistance[i] = (int*)malloc(k * sizeof(int));
            for (int j = 0; j < k; ++j) {
            
                arrayDistance[i][j] = 1000;
            }
        }
        arrayDistance[1][0] = 0;

        Queue* pq = (Queue*)malloc((n * k) * sizeof(Queue));

        int pqSize = 0;
        pq[pqSize++] = (Queue){ 1, 0 };

        while (pqSize > 0) {

            Queue top = pq[0];
            memmove(pq, pq + 1, (pqSize - 1) * sizeof(Queue));
            
            pqSize--;
            int a = top.node;
            int b = top.cost;

            if (arrayDistance[a][k - 1] < b) {
             
                continue;
            }

            int i;
            #pragma omp parallel for
            for (i = 0; i < qSize[a]; ++i) {
                
                int dest = q[a][i].node;
                int cost = q[a][i].cost;

                #pragma omp critical
                {
                    if (b + cost < arrayDistance[dest][k - 1]) {
                        
                        arrayDistance[dest][k - 1] = b + cost;
                
                        for (int j = k - 1; j > 0 && arrayDistance[dest][j] < arrayDistance[dest][j - 1]; --j) {
                        
                            int temp = arrayDistance[dest][j];
                            arrayDistance[dest][j] = arrayDistance[dest][j - 1];
                            arrayDistance[dest][j - 1] = temp;
                        }

                        pq[pqSize++] = (Queue){ dest, b + cost };

                        for (int j = pqSize - 1; j > 0 && pq[j].cost < pq[j - 1].cost; --j) {

                            Queue temp = pq[j];
                            pq[j] = pq[j - 1];
                            pq[j - 1] = temp;
                        }
                    }
                }
            }
        }

        int** all_arrayDistance = NULL;

        if (rank == 0) {
            all_arrayDistance = (int**)malloc(size * sizeof(int*));

            for (int i = 0; i < size; ++i) {

                all_arrayDistance[i] = (int*)malloc(k * sizeof(int));
            }
        }

        MPI_Gather(arrayDistance[n], k, MPI_INT, all_arrayDistance, k, MPI_INT, 0, MPI_COMM_WORLD);

        for (int i = 0; i < k; ++i) {

            if (arrayDistance[n][i] != INT_MAX) {

                printf("%d ", arrayDistance[n][i]);
            }
        }

        printf("\n");

        for (int i = 0; i <= n; ++i) {

            free(q[i]);
            free(arrayDistance[i]);
        }

        free(q);
        free(qSize);
        free(arrayDistance);
        free(pq);
    }
}

int main(int argc, char** argv) {

    MPI_Init(&argc, &argv);

    int rank, size;
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    int N, M, K = 10;
    int(*edges)[3] = NULL;

    if (rank == 0) {
        FILE* file = fopen("2.txt", "r");
        if (file == NULL) {
    
            perror("Error opening file");
            MPI_Abort(MPI_COMM_WORLD, 1);
        }

        fscanf_s(file, "# Nodes: %d Edges: %d", &N, &M);

        edges = (int(*)[3])malloc(M * sizeof(*edges));

        if (edges == NULL) {

            perror("Memory allocation failed");
            fclose(file);
            return 1;
        }
        
        srand((unsigned int)time(NULL));
        int index = 0, u, v;
        char line[128];

        while (fgets(line, sizeof(line), file)) {
        
            if (line[0] == '#') {
             
                continue; 
            }

            if (sscanf_s(line, "%d\t%d", &u, &v) == 2) {
            
                edges[index][0] = u;
                edges[index][1] = v;
                edges[index][2] = rand() % 20 + 1;

                printf("%d, %d, %d\n", edges[index][0], edges[index][1], edges[index][2]);
                index++;
            }
        }

        fclose(file);
    }

    MPI_Barrier(MPI_COMM_WORLD);

    MPI_Bcast(&N, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&M, 1, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Bcast(&K, 1, MPI_INT, 0, MPI_COMM_WORLD);

    if (rank != 0) {

        edges = (int(*)[3])malloc(M * sizeof(*edges));
    }

    MPI_Bcast(edges, M * 3, MPI_INT, 0, MPI_COMM_WORLD);

    findKShortest(edges, N, M, K, rank, size);

    free(edges);
    MPI_Finalize();
    return 0;
}