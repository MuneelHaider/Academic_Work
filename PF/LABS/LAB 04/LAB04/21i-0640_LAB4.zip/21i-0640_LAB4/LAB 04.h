#include <iostream>
#pragma once

#include "gtest/gtest.h"
using namespace std;

void task1(int n, int c) {

    if (n == 0) {
        if (c == 0) {

            return;
        }
        
        cout << endl;
        return task1(n + c, c - 1);
    }
    else {

        cout << "*";
        return task1(n - 1, c);
    }
}

int getcharcount(const char* ptr, char c) {

    if (*ptr == '\0') {

        return 0;
    }

    else if (*ptr == c) {

        return 1 + getcharcount(ptr + 1, c);
    }
    else {

        return getcharcount(ptr + 1, c);
    }
}

int getunicharcount(const char* ptr, const char* current) {

    if (*ptr == '\0') {

        return 0;
    }

    if (getcharcount(ptr, *ptr) > 1) {

        return getunicharcount(ptr + 1, current);
    }
    else {

        return 1 + getunicharcount(ptr + 1, current);
    }

}