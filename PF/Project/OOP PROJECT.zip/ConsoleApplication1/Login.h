//#pragma once
//#include <iostream>
//#include <fstream>
//
//using namespace std;
//
//class Login {
//
//	Patient* patient_login;
//	Doctor* doctor_login;
//	Admin* admin_login;
//	bool login_success;
//	string username;
//	string password;
//
//public:
//
//	Login(bool flag = false, string username = "", string password = "") {
//
//		login_success = flag;
//		this->username = username;
//		this->password = password;
//	}
//
//	void setlogin_success(bool flag) {
//
//		login_success = flag;
//	}
//	bool getlogin_success() {
//
//		return login_success;
//	}
//
//	void setUsername(string n) {
//
//		username = n;
//	}
//	string getUsername() {
//
//		return username;
//	}
//
//	void setPassword(string p) {
//
//		password = p;
//	}
//	string getPassword() {
//
//		return password;
//	}
//};