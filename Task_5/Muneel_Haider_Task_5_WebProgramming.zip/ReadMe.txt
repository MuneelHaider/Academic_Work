Made by Muneel Haider 21i-0640

To run server: 

	cd server
	npm run server


To run client: 

	cd client
	npm start


After running server, you should receive a notification that says that MongoDB is connected successfully.