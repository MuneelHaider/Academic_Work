export default async function InvoicesPage() {
    return (
      <div>
        <h1>Invoices Page</h1>
        <a href="/dashboard">Back to Dashboard</a>
      </div>
    );
  }
  