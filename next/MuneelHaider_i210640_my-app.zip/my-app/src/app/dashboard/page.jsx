export default function DashboardPage() {
    return (
      <div>
        <h1>Dashboard Home</h1>
        <ul>
          <li><a href="/dashboard/customer">Go to Customers</a></li>
          <li><a href="/dashboard/invoices">Go to Invoices</a></li>
        </ul>
      </div>
    );
  }
  